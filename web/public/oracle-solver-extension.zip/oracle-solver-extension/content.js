(() => {
  // Prevent duplicate top-level injection in the same frame
  if (window.__oracleAutoPilotLoaded) return;
  window.__oracleAutoPilotLoaded = true;

  const CONFIG = {
    LOOP_INTERVAL_MS: 350,
    NAV_COOLDOWN_MS: 1500,
    MAX_STALE_REPOSTS: 3,
    REPOST_MIN_INTERVAL_MS: 5000,
    DEFAULT_SERVER: 'https://sleek-oyster-317.convex.site',
    TARGET_OUTLINE_URL:
      'https://academy.oracle.com/pls/f?p=63000:14:405939804972376:::14:P14_ID,P14_COURSE_ID:60121,66&cs=3pD3KfCV_Y_o9BCNmcvKcvrNKUpknT8dmk7GpHCM8e-Tjhq6AI9fEziAq29cP12snqyABLxhS5eBIo_RCuWQw5A',
    TARGET_CLASSES: [
      'Database Foundations',
      'Database Programming with PLSQL',
      'Database Design'
    ]
  };

  let isSolvingQuiz = false;
  let lastNavActionTime = 0;
  let lastReportedState = '';
  let lastSubmittedSnippet = '';
  let lastCompleteAssessmentClickTime = 0;
  let isQuizCompletedAwaitingUser = false;   // was previously an undeclared global (latent bug)

  // Access-control state: the relay tells us via /health whether login is
  // required (cloud mode / local users). When required and not verified, the
  // autopilot stays idle instead of clicking around unauthenticated.
  const authState = { required: null, ok: false, checkedAt: 0 };

  // Kill switch controllable from the extension popup.
  let autopilotEnabled = true;

  // Course-outline helpers state
  let lastOutlineNavTime = 0;

  // Quiz watchdog state: same "Question X of Y" stuck on screen for too long
  const quizWatch = { qNum: '', firstSeen: 0, submitRetried: false, altTried: false, reloadQueued: false };

  // Force-guess counter: relay could not answer this question N times
  let unansweredAttempts = 0;
  let lastSnippetPosted = '';

  const log = (...a) => console.log('[autopilot]', ...a);
  const warn = (...a) => console.warn('[autopilot]', ...a);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // Never let a scroll failure abort a click flow (some embedded/boundary
  // contexts throw on scrollIntoView).
  function safeScrollIntoView(el) {
    try {
      if (el && typeof el.scrollIntoView === 'function') {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    } catch (e) {}
  }

  // Ensure PL/SQL is not prematurely marked complete in localStorage
  try {
    const raw = localStorage.getItem('oracle_completed_classes');
    if (raw) {
      let arr = JSON.parse(raw);
      if (Array.isArray(arr)) {
        arr = arr.filter((c) => !c.toLowerCase().includes('plsql') && !c.toLowerCase().includes('pl/sql'));
        localStorage.setItem('oracle_completed_classes', JSON.stringify(arr));
      }
    }
  } catch (e) {}

  async function api(method, path, body) {
    return new Promise((resolve, reject) => {
      // Degraded route: direct fetch with CORS (the cloud sends
      // Access-Control-Allow-Origin: *) used only when the extension context
      // is unavailable (e.g. invalidated during reload). It must target the
      // SAME server as background.js — pointing at a local relay that isn't
      // running made every request fail and read as "offline".
      const send = async () => {
        try {
          let d = {};
          try {
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
              d = await new Promise((r) => chrome.storage.local.get(['serverUrl', 'session', 'deviceId'], (x) => r(x || {})));
            }
          } catch (e) {}
          const server = d.serverUrl && String(d.serverUrl).startsWith('http')
            ? String(d.serverUrl).replace(/\/+$/, '')
            : CONFIG.DEFAULT_SERVER;
          const headers = {};
          if (body) headers['Content-Type'] = 'application/json';
          if (d.session && d.session.token) headers['Authorization'] = 'Bearer ' + d.session.token;
          if (d.deviceId) headers['X-Device-Id'] = d.deviceId;
          const res = await fetch(server + path, {
            method,
            headers,
            body: body ? JSON.stringify(body) : undefined
          });
          let parsed = null;
          try {
            parsed = await res.json();
          } catch (e) {}
          if (res.status === 401) {
            authState.required = true;
            authState.ok = false;
            authState.checkedAt = Date.now();
          }
          if (!res.ok) return reject(new Error(parsed && parsed.error ? parsed.error : 'HTTP ' + res.status));
          resolve({ status: res.status, body: parsed });
        } catch (e) {
          reject(new Error(String(e && e.message ? e.message : e)));
        }
      };

      try {
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
          send();
          return;
        }
        chrome.runtime.sendMessage({ type: 'RELAY_FETCH', method, path, body }, (res) => {
          if (chrome.runtime.lastError) {
            // Background unreachable — degrade to direct fetch instead of dying.
            send();
            return;
          }
          if (res && res.status === 401) {
            // Token rejected/expired — background.js clears the session; the
            // autopilot will idle until the user logs in from the popup.
            authState.required = true;
            authState.ok = false;
            authState.checkedAt = Date.now();
          }
          if (!res || !res.ok) {
            return reject(new Error(res ? res.error || 'HTTP ' + res.status : 'Network request failed'));
          }
          resolve({ status: res.status, body: res.body });
        });
      } catch (e) {
        send();
      }
    });
  }

  // Ask the relay whether access control is on and whether our token is valid.
  // Throttled internally to one probe every 4s.
  async function probeAuth(force) {
    const now = Date.now();
    if (!force && now - authState.checkedAt < 4000) return authState;
    authState.checkedAt = now;
    try {
      const h = await api('GET', '/health');
      authState.required = !!(h.body && h.body.auth && h.body.auth.required);
      if (!authState.required) {
        authState.ok = true;
        return authState;
      }
      // /me doubles as an identity probe. A real auth rejection (401/403)
      // locks the autopilot; any other non-200 (5xx hiccup) keeps the last
      // known state so a transient server error can't stall the run.
      const w = await api('GET', '/me');
      if (w.status === 401 || w.status === 403) {
        authState.ok = false;
      } else {
        authState.ok = w.status === 200 && !!(w.body && w.body.ok && w.body.userId);
      }
    } catch (e) {
      /* relay unreachable — keep last known state */
    }
    return authState;
  }

  // Popup toggle: autopilotEnabled in chrome.storage.local (default true).
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['autopilotEnabled'], (d) => {
        if (d && d.autopilotEnabled === false) autopilotEnabled = false;
      });
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && Object.prototype.hasOwnProperty.call(changes, 'autopilotEnabled')) {
          autopilotEnabled = changes.autopilotEnabled.newValue !== false;
          log('Autopilot toggled ' + (autopilotEnabled ? 'ON' : 'OFF') + ' from popup');
          // START SOLVING also clears the navigation budget so a paused run
          // can proceed again.
          if (autopilotEnabled) navs = [];
        }
      });
    }
  } catch (e) {}

  // Background re-probes auth after login/logout.
  try {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg && msg.type === 'SESSION_UPDATED') {
          authState.ok = false;
          authState.checkedAt = 0;
          probeAuth(true);
        }
      });
    }
  } catch (e) {}

  function reportState(state, action = '') {
    const key = `${state}|${action}`;
    if (key === lastReportedState) return;
    lastReportedState = key;
    api('POST', '/page-state', {
      title: document.title || '',
      url: typeof location !== 'undefined' ? location.href : '',
      state,
      action
    }).catch(() => {});
  }

  let _cachedText = '';
  let _cachedTextTime = 0;
  function bodyText() {
    const now = Date.now();
    if (now - _cachedTextTime < 80) return _cachedText;
    _cachedText = document.body ? document.body.innerText : '';
    _cachedTextTime = now;
    return _cachedText;
  }

  function norm(s) {
    return String(s || '').replace(/\s+/g, ' ').trim();
  }

  function textOk(elText, choice) {
    const a = norm(elText);
    const b = norm(choice);
    if (!a || !b) return false;
    if (a === b) return true;
    const delta = Math.abs(a.length - b.length);
    if (delta > 80) return false;
    if (a.includes(b)) return true;
    if (b.includes(a)) return a.length >= 15;
    const snip = b.slice(0, 25);
    return snip.length >= 15 && a.includes(snip);
  }

  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    return true;
  }

  function canClickNav() {
    return Date.now() - lastNavActionTime > CONFIG.NAV_COOLDOWN_MS;
  }

  // --- Dead-loop click guard ---------------------------------------------------
  // It used to be possible to re-click one unresponsive button forever, and
  // because every click scrollIntoView'd, the page would keep yanking back to
  // it (feeling like "the page won't scroll"). Now: track clicks per target
  // signature; if the page is unchanged after several attempts, back off 60s.
  const clickGuard = new Map();
  let clickGuardUrl = '';

  function bodyTextHash() {
    const t = String(bodyText() || '').slice(0, 500);
    let h = 0;
    for (let i = 0; i < t.length; i++) h = (h * 31 + t.charCodeAt(i)) & 0xffff;
    return h;
  }

  function targetSig(el, description) {
    let top = 0;
    try {
      const r = el.getBoundingClientRect();
      top = Math.round((r.top || 0) / 60);
    } catch (e) {}
    return (
      (norm(el.innerText || el.value || '').slice(0, 40) || description.slice(0, 30)) +
      '|' + (el.tagName || '') + '|' + top
    );
  }

  // Returns null (do not click) or { first: boolean }.
  function shouldClick(el, description) {
    const href = (typeof location !== 'undefined' && location.href) || '';
    if (href !== clickGuardUrl) {
      clickGuard.clear();
      clickGuardUrl = href;
    }
    const sig = targetSig(el, description);
    const now = Date.now();
    let g = clickGuard.get(sig);
    if (g && g.blockUntil > now) return null;
    if (!g) {
      g = { count: 0, firstAt: now, textHashAtFirst: bodyTextHash(), blockUntil: 0 };
      clickGuard.set(sig, g);
    }
    g.count++;
    if (g.count >= 4 && now - g.firstAt < 15000 && bodyTextHash() === g.textHashAtFirst) {
      g.blockUntil = now + 60000;
      warn('Target unresponsive after 4 clicks with no page change — backing off 60s:', description);
      reportState('Backoff', description + ' had no effect');
      return null;
    }
    if (bodyTextHash() !== g.textHashAtFirst) {
      // Page changed since we started — reset the window.
      g.count = 1;
      g.firstAt = now;
      g.textHashAtFirst = bodyTextHash();
    }
    return { first: g.count === 1 };
  }

  function triggerNavClick(el, description, ignoreCooldown = false) {
    if (!el || (!ignoreCooldown && !canClickNav()) || !isVisible(el)) return false;

    const guard = shouldClick(el, description);
    if (!guard) return false;

    lastNavActionTime = Date.now();
    log(`[Action: ${description}] Clicking:`, el);
    reportState('Navigating', `${description}: ${norm(el.innerText || el.value || '')}`);
    // Scroll only on the first attempt of a target — repeated scrolling is
    // what made pages feel "stuck and unscrollable".
    if (guard.first) safeScrollIntoView(el);

    const href = el.getAttribute ? el.getAttribute('href') : null;
    if (href && href.startsWith('javascript:')) {
      try {
        const code = href.replace(/^javascript:/i, '');
        const script = document.createElement('script');
        script.textContent = code;
        (document.head || document.documentElement).appendChild(script);
        script.remove();
      } catch (e) {}
    }

    // Synthetic mouse events help APEX handlers notice the interaction; a
    // missing/blocked MouseEvent must never abort the real click below.
    try {
      el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
      el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
      el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
    } catch (e) {}
    el.click();
    return true;
  }

  // --- Modals and Popups ---
  // Strictly disabled: user manually starts assessments and handles modals
  function handleModals() {
    return false;
  }

  // --- Quiz Question Extraction & Solving ---
  function questionFromText() {
    const t = bodyText();
    let m = t.match(/Question\s+\d+\s+of\s+\d+[\s\S]*?(?=Choices)/i);
    if (m) return m[0].trim();
    m = t.match(/Question\s+\d+\s+of\s+\d+[\s\S]*?(?=\n\s*True\s+or\s+False\s*\?\s*\n)/i);
    if (m) return m[0].trim();
    m = t.match(/Question\s*\d+[^\n]*/i);
    return m ? m[0].trim() : '';
  }

  function findClickable(choiceText, allChoices) {
    const b = norm(choiceText);
    if (!b) return null;

    const choices = Array.isArray(allChoices)
      ? allChoices.map((c) => norm(typeof c === 'string' ? c : c.text)).filter(Boolean)
      : [];
    const radioInputs = Array.from(
      document.querySelectorAll('input[type="radio"], input[type="checkbox"]')
    );

    // Direct 1-to-1 match by index
    if (choices.length > 1 && radioInputs.length === choices.length) {
      const idx = choices.indexOf(b);
      if (idx >= 0) return radioInputs[idx];
    }

    // Oracle APEX label & container matching
    for (const inp of radioInputs) {
      if (inp.id) {
        const label = document.querySelector(`label[for="${CSS.escape(inp.id)}"]`);
        if (label && textOk(label.innerText, b)) return inp;
      }
      const container = inp.closest('tr, li, div.apex-item-option, div');
      if (container && textOk(container.innerText, b)) {
        return inp;
      }
    }

    // Text fallback scanning containers
    const all = Array.from(document.querySelectorAll('label, span, td, div'));
    for (const el of all) {
      if (textOk(el.innerText, b)) {
        const parentContainer = el.closest('tr, li, div');
        const inp = parentContainer
          ? parentContainer.querySelector('input[type="radio"], input[type="checkbox"]')
          : null;
        if (inp) return inp;
        // No input inside — click the matching container itself (div/td/label
        // based quiz UIs where the whole row is the clickable target).
        return el;
      }
    }

    return null;
  }

  function extractDom() {
    const inputs = Array.from(
      document.querySelectorAll('input[type="radio"], input[type="checkbox"]')
    ).filter(isVisible);

    if (inputs.length < 2) return null;

    const groups = new Map();
    for (const inp of inputs) {
      const container = inp.closest('.apex-item-group, .apex-item-checkbox, .apex-item-radio, fieldset, table, ul, .t-Form-inputContainer, div');
      const key = inp.name || container || 'default';
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(inp);
    }
    let best = null;
    for (const g of groups.values()) {
      if (g.length >= 2 && (!best || g.length > best.length)) best = g;
    }
    if (!best || best.length < 2) best = inputs;
    const choices = [];
    for (const inp of best) {
      let text = '';
      if (inp.id) {
        const lab = document.querySelector('label[for="' + CSS.escape(inp.id) + '"]');
        if (lab) text = lab.innerText.trim();
      }
      if (!text && inp.closest('label')) text = inp.closest('label').innerText.trim();
      if (!text && inp.parentElement) text = inp.parentElement.innerText.trim();
      if (!text) continue;
      let handle = null;
      if (inp.id) handle = { kind: 'id', id: inp.id };
      else if (inp.name && inp.value) handle = { kind: 'name-value', name: inp.name, value: inp.value };
      choices.push({ text, handle });
    }
    if (choices.length < 2) return null;
    return {
      kind: 'dom',
      choices,
      resolve(n) {
        const c = choices[n - 1];
        if (!c) return null;
        if (c.handle) {
          if (c.handle.kind === 'id') {
            const el = document.getElementById(c.handle.id);
            if (el) return el;
          } else {
            const el = document.querySelector(
              'input[name="' +
                CSS.escape(c.handle.name) +
                '"][value="' +
                CSS.escape(c.handle.value) +
                '"]'
            );
            if (el) return el;
          }
        }
        return findClickable(c.text, choices.map((x) => x.text));
      }
    };
  }

  function choiceButtonNodes() {
    const btns = Array.from(document.querySelectorAll('button.choice-SelectArea'));
    if (btns.length >= 2) return btns;
    const ctrs = Array.from(document.querySelectorAll('.choice-Container'));
    if (ctrs.length >= 2) return ctrs;
    return [];
  }

  function extractButtons() {
    const nodes = choiceButtonNodes();
    if (nodes.length < 2) return null;
    const choices = [];
    for (const n of nodes) {
      const t = n.querySelector('.choice-Text') || n;
      const text = norm(t.innerText);
      if (text) choices.push({ text });
    }
    if (choices.length < 2) return null;
    return {
      kind: 'buttons',
      choices,
      resolve(k) {
        const list = choiceButtonNodes();
        const el = list[k - 1];
        if (!el) return null;
        return el.matches('button') ? el : el.querySelector('button') || el;
      }
    };
  }

  function extractText() {
    const t = bodyText();
    let choiceTexts = [];
    const afterChoices = t.split(/Choices[^\n]*/i)[1];
    if (afterChoices !== undefined) {
      const block = afterChoices.split(/Submit Answer|Previous Question|Version\s+\d/i)[0] || '';
      const junk = /^(?:instructions|mark for review|save answer|clear|question\s+\d+\s+of\s+\d+|\u00a9|copyright)/i;
      const oracleBoilerplate = /oracle\s+and\/or\s+its\s+affiliates/i;
      choiceTexts = block
        .split('\n')
        .map((s) => s.trim())
        .filter((s) => s && !junk.test(s) && !oracleBoilerplate.test(s));
    } else if (/True\s+or\s+False\s*\?/i.test(t)) {
      const m = t.match(
        /True\s+or\s+False\s*\?([\s\S]*?)(?:Submit Answer|Previous Question|Version\s+\d)/i
      );
      const block = m ? m[1] : '';
      const seen = new Set();
      for (const line of block.split('\n')) {
        const s = line.trim();
        if (/^(?:true|false)$/i.test(s) && !seen.has(s.toLowerCase())) {
          seen.add(s.toLowerCase());
          choiceTexts.push(s);
        }
      }
      if (choiceTexts.length < 2) choiceTexts = ['True', 'False'];
    } else {
      return null;
    }
    if (choiceTexts.length < 2) return null;
    return {
      kind: 'text',
      question: questionFromText(),
      choices: choiceTexts,
      resolve(n) {
        return findClickable(choiceTexts[n - 1] || '', choiceTexts);
      }
    };
  }

  function extractQuestion() {
    const btns = extractButtons();
    if (btns) return { kind: 'buttons', question: questionFromText(), choices: btns.choices, resolve: btns.resolve };
    const dom = extractDom();
    if (dom) return { kind: 'dom', question: questionFromText(), choices: dom.choices, resolve: dom.resolve };
    return extractText();
  }

  function clickChoice(el) {
    if (!el) return;
    let inp = null;
    let label = null;

    if (el.tagName === 'INPUT') {
      inp = el;
      if (inp.id) {
        label = document.querySelector(`label[for="${CSS.escape(inp.id)}"]`);
      }
      if (!label) label = inp.closest('label');
    } else if (el.tagName === 'LABEL') {
      label = el;
      if (label.htmlFor) {
        inp = document.getElementById(label.htmlFor);
      }
      if (!inp) inp = label.querySelector('input');
    } else {
      inp = el.querySelector ? el.querySelector('input') : null;
      label = el.querySelector ? el.querySelector('label') : null;
    }

    const target = label || inp || el;
    safeScrollIntoView(target);

    if (inp && (inp.type === 'radio' || inp.type === 'checkbox')) {
      if (!inp.checked) {
        if (label) {
          label.click();
        } else {
          inp.click();
        }
      }
      if (!inp.checked) {
        inp.checked = true;
      }
      inp.dispatchEvent(new Event('input', { bubbles: true }));
      inp.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }

    target.click();
  }

  function checkIsLastQuestion() {
    const m = bodyText().match(/question\s+(\d+)\s+of\s+(\d+)/i);
    return m ? parseInt(m[1], 10) === parseInt(m[2], 10) : false;
  }

  // Accepts every wording Oracle has used for the finish button.
  function isCompleteAssessmentText(txt) {
    const t = norm(txt).toLowerCase();
    if (!t) return false;
    if (/complete( the)? assessment|submit( the)? assessment|finish( the)? assessment|end( the)? assessment|submit exam|finish exam/.test(t)) return true;
    return t === 'complete assessment';
  }

  function isConfirmModalText(text) {
    return (
      /are\s+you\s+sure.*\?/i.test(text) && /submission|submit|assessment/i.test(text) ||
      /submit\s+your\s+assessment\?/i.test(text) ||
      /return\s+to\s+assessment/i.test(text) ||
      /final\s+submission/i.test(text)
    );
  }

  function clickCompleteAssessmentButton() {
    const buttons = Array.from(
      document.querySelectorAll('button, a, input[type="button"], input[type="submit"]')
    ).filter(isVisible);

    const btn = buttons.find((b) => isCompleteAssessmentText(b.innerText || b.value || ''));

    if (btn) {
      log('Clicking Complete Assessment button:', btn);
      safeScrollIntoView(btn);
      lastCompleteAssessmentClickTime = Date.now();
      btn.click();
      return true;
    }
    return false;
  }

  // Escalating fallbacks when the normal "Submit Answer" button can't be found.
  function tryAlternateSubmit() {
    // On the last question the real goal is finishing: try finish-style buttons first.
    const finish = Array.from(
      document.querySelectorAll('button, a, input[type="button"], input[type="submit"], [role="button"]')
    ).filter(isVisible).find((b) => isCompleteAssessmentText(b.innerText || b.value || ''));
    if (finish) {
      log('Alternate submit: finish-style button found:', finish);
      return triggerNavClick(finish, 'Alternate submit: finish assessment', true);
    }

    const sels = [
      'button[aria-label*="submit" i]',
      'button[aria-label*="next" i]',
      'a[aria-label*="next" i]',
      '.submit-button',
      'button[type="submit"]'
    ];
    for (const sel of sels) {
      const el = Array.from(document.querySelectorAll(sel)).find(isVisible);
      if (el) {
        log('Alternate submit click:', sel);
        return triggerNavClick(el, 'Alternate submit: ' + sel, true);
      }
    }
    try {
      const form = document.querySelector('form');
      if (form) {
        if (typeof form.requestSubmit === 'function') form.requestSubmit();
        else form.submit();
        log('Dispatched form submit as last resort');
        return true;
      }
    } catch (e) {}
    warn('No alternate submit strategy worked.');
    return false;
  }

  function clickSubmitAnswer() {
    const isLastQuestion = checkIsLastQuestion();

    const buttons = Array.from(
      document.querySelectorAll('button, a, input[type="button"], input[type="submit"]')
    ).filter(isVisible);

    let btn = buttons.find((b) => {
      const txt = norm(b.innerText || b.value || '').toLowerCase();
      // On the last question, finish-style buttons can BE the submit.
      if (isLastQuestion && isCompleteAssessmentText(txt)) return true;
      return (
        txt.includes('submit answer') ||
        txt === 'next question' ||
        txt === 'next' ||
        txt.includes('save answer')
      );
    });

    if (btn) {
      log('Clicking Submit/Next Question button:', btn);
      safeScrollIntoView(btn);
      btn.click();
    } else {
      warn('Submit Answer button not found — trying alternates.');
      tryAlternateSubmit();
    }
  }

  let solvingQuizStartTime = 0;
  // Once a LAST question has been answered, never answer it again — repeated
  // re-answering is what looked like "rotating options" forever. The
  // Complete/confirm/results handlers take over from here per session.
  function lastQuestionBlocked(snippet) {
    try {
      const key = 'lastq_done:' + snippet;
      return !!sessionStorage.getItem(key);
    } catch (e) {
      return false;
    }
  }

  function blockLastQuestion(snippet) {
    try {
      if (snippet) sessionStorage.setItem('lastq_done:' + snippet, String(Date.now()));
    } catch (e) {}
  }

  async function runQuizFlow() {
    if (isSolvingQuiz) return;
    isSolvingQuiz = true;
    solvingQuizStartTime = Date.now();
    reportState('Solving Quiz Question');

    try {
      const data = extractQuestion();
      if (!data || !data.choices || data.choices.length < 2) {
        warn('Could not extract active question/choices cleanly.');
        return;
      }

      const snippet = norm(data.question || '').slice(0, 120);

      // A last question already answered this session is OFF LIMITS for the
      // solver — only the finish/modal/results handlers act on it now.
      if (checkIsLastQuestion() && lastQuestionBlocked(snippet)) {
        return;
      }
      if (snippet && snippet === lastSubmittedSnippet && Date.now() - lastNavActionTime < 10000) {
        return;
      }

      const payload = {
        question: data.question || '(question text not extracted)',
        choices: data.choices.map((c) => (typeof c === 'string' ? c : c.text)),
        extractionFailed: false,
        attempt: parseInt(sessionStorage.getItem('auto_attempts') || '0', 10) || 0
      };
      const markedWrongNow = isMarkedWrong(norm(data.question || ''));
      if (markedWrongNow) {
        payload.attempt = Math.max(payload.attempt, 1);
        log('This question was incorrect last attempt — forcing API re-solve.');
      }

      log(`Posting question: "${payload.question.slice(0, 60)}..." (${payload.choices.length} choices)`);
      lastSnippetPosted = snippet;
      const r = await api('POST', '/question', payload);
      if (r.status !== 200 || !r.body || !r.body.qid) {
        warn('POST /question failed');
        return;
      }

      const qid = r.body.qid;
      log(`Question qid=${qid} posted. Polling for answer...`);

      // Cloud mode delivers the answer with the POST itself. Relay mode
      // delivers it through /answer-poll.
      let answered = false;
      const nsDirect =
        r.body.ns && Array.isArray(r.body.ns) && r.body.ns.length ? r.body.ns : null;

      const pollStartTime = Date.now();
      const applyAnswer = async (ns) => {
        log(`Received answer ns=[${ns.join(', ')}]`);
        lastSubmittedSnippet = snippet;
        unansweredAttempts = 0;
        answered = true;
        const isLast = checkIsLastQuestion();
        let clickedAny = false;
        for (const n of ns) {
          const target = data.resolve(n);
          if (target) {
            clickChoice(target);
            clickedAny = true;
            log(`Clicked choice ${n}: "${payload.choices[n - 1]}"`);
            await sleep(60);
          } else {
            warn(`Could not resolve target for choice ${n}`);
          }
        }
        if (clickedAny) {
          await sleep(100);
          clickSubmitAnswer();
          lastNavActionTime = Date.now();
        } else {
          warn('No choice could be clicked — not submitting.');
        }

        // Opportunistic learning: if Oracle reveals the correct answer in its
        // feedback, store it so every future attempt (and the auto-retake)
        // answers this question correctly.
        if (!isLast) {
          harvestFeedback(data.question, payload.choices);
        }

        if (isLast) {
          blockLastQuestion(snippet);
          log('Last question answered! Waiting for the Complete Assessment button...');
          let confirmed = false;
          // Give the page a moment to reveal the finish button, then act.
          for (let attempt = 0; attempt < 12; attempt++) {
            await sleep(500);
            if (await handleConfirmCompleteModal()) { confirmed = true; break; }
            if (await handleTopCompleteAssessment()) { confirmed = true; break; }
          }
          if (!confirmed) {
            // Nothing worked — capture the real page state for diagnosis
            // instead of guessing again.
            sendDiag('lastq-no-finish', data.question, payload.choices);
          }
        }
      };

      while (!nsDirect && Date.now() - pollStartTime < 20000) {
        let poll = null;
        try {
          poll = await api('GET', '/answer-poll?qid=' + qid);
        } catch (e) {
          await sleep(300);
          continue;
        }

        if (poll && poll.body && poll.body.stale) {
          log('Poll reported stale qid');
          break;
        }

        if (poll && poll.body && Array.isArray(poll.body.ns) && poll.body.ns.length) {
          await applyAnswer(poll.body.ns);
          break;
        }
        await sleep(100);
      }

      // Cloud mode: the answer arrived with POST /question itself (kept in
      // nsDirect; the while loop is skipped for it).
      if (nsDirect) {
        await applyAnswer(nsDirect);
      }

      // The solver could not answer this question (no key / AI down / no cache).
      // After the third failed cycle, force-guess the first choice so the quiz
      // keeps moving instead of looping on the same question forever.
      if (!answered) {
        unansweredAttempts++;
        if (snippet && snippet === lastSnippetPosted && unansweredAttempts >= 3) {
          warn(`No answer after ${unansweredAttempts} attempts — force-guessing choice 1 to keep the quiz moving.`);
          const first = data.resolve(1);
          if (first) clickChoice(first);
          await sleep(120);
          clickSubmitAnswer();
          lastSubmittedSnippet = snippet;
          lastNavActionTime = Date.now();
          unansweredAttempts = 0;
        }
      }
    } catch (e) {
      warn('Quiz solver error:', e.message);
    } finally {
      await sleep(30);
      isSolvingQuiz = false;
    }
  }

  // --- Wrong-question ledger (retake targeting) ---------------------------------
  // The results screen's incorrect rows are recorded per session. On the
  // retake, marked questions skip the answer database entirely and are
  // re-solved by the API (attempt-aware cloud path), so wrong answers are
  // actually re-answered, not replayed.
  function wrongList() {
    try {
      return JSON.parse(sessionStorage.getItem('wrongq') || '[]');
    } catch (e) {
      return [];
    }
  }

  function addWrong(snippet) {
    const key = norm(snippet || '').slice(0, 160);
    if (!key) return;
    try {
      const list = wrongList();
      if (!list.some((x) => key.includes(x.key) || x.key.includes(key))) {
        list.push({ key });
        if (list.length > 50) list.shift();
        sessionStorage.setItem('wrongq', JSON.stringify(list));
        log('Marked for API re-solve on retake:', key.slice(0, 60));
      }
    } catch (e) {}
  }

  function isMarkedWrong(snippet) {
    const key = norm(snippet || '').slice(0, 160);
    return wrongList().some((x) => key.includes(x.key) || x.key.includes(key));
  }

  function clearWrongList() {
    try {
      sessionStorage.removeItem('wrongq');
    } catch (e) {}
  }

  // Read the results screen: mark every incorrect row's question text.
  function captureWrongRows() {
    let n = 0;
    const rows = Array.from(document.querySelectorAll('tr, li, .row, div')).filter(isVisible);
    for (const el of rows) {
      const t = norm(el.innerText || '');
      if (t.length < 20 || t.length > 600) continue;
      if (!/incorrect|marked\s+wrong|partial/i.test(t)) continue;
      if (/^incorrect$/i.test(t)) continue;
      addWrong(t);
      n++;
    }
    if (n) log(`Results screen: ${n} incorrect answers marked for AI re-solve.`);
    return n > 0;
  }

  // --- Learn from Oracle's feedback + diagnostics capture ----------------------

  function extractCorrectAnswer(text) {
    let m = text.match(/correct\s+answer\s*(?:is)?\s*[:\-]?\s*["“]?([^\n]{2,160})/i);
    if (m) return norm(m[1]).slice(0, 160);
    m = text.match(/answer\s*[:\-]\s*([^\n]{2,160})/i);
    if (m) return norm(m[1]).slice(0, 160);
    const els = Array.from(
      document.querySelectorAll('[class*="correct" i], [class*="answerKey" i], .correct-answer')
    ).filter(isVisible);
    for (const el of els) {
      const t = norm(el.innerText || '');
      if (t && t.length > 1 && !/your\s+answer/i.test(t)) return t.slice(0, 160);
    }
    return '';
  }

  async function harvestFeedback(question, choices) {
    await sleep(2500);
    try {
      const text = bodyText();
      if (isConfirmModalText(text)) return;
      if (!/incorrect|wrong|not\s+correct/i.test(text)) return;
      const correct = extractCorrectAnswer(text);
      if (!correct || correct.length < 2) {
        sendDiag('feedback-no-answer', question, choices);
        return;
      }
      await api('POST', '/answers', { question, choices, answerTexts: [correct], source: 'feedback' });
      log('Learned the correct answer from Oracle feedback — saved to the shared database.');
    } catch (e) {}
  }

  async function sendDiag(kind, question, choices) {
    try {
      const buttons = Array.from(
        document.querySelectorAll('button, a, [role="button"], input[type="button"], input[type="submit"]')
      ).filter(isVisible)
        .map((b) => norm(b.innerText || b.value || '').slice(0, 80))
        .filter(Boolean)
        .slice(0, 20);
      await api('POST', '/diag', {
        kind,
        question: norm(question).slice(0, 300),
        choices: (choices || []).map((c) => norm(c).slice(0, 120)).slice(0, 12),
        url: ((typeof location !== 'undefined' && location.href) || '').slice(0, 300),
        text: bodyText().slice(0, 2500),
        buttons
      });
      log('Captured page diagnostics for', kind);
    } catch (e) {}
  }

  // --- End of Quiz / Submit Assessment ---
  let lastTopCompleteClickTime = 0;
  let lastModalConfirmClickTime = 0;

  function isLastQuestionAnsweredAndSelected() {
    if (!checkIsLastQuestion()) return false;
    const anyChecked = document.querySelector(
      'input[type="radio"]:checked, input[type="checkbox"]:checked, .apex-item-option input:checked'
    ) !== null;
    return anyChecked;
  }

  async function handleConfirmCompleteModal() {
    const text = bodyText();
    const isConfirmModalOpen = isConfirmModalText(text);

    if (!isConfirmModalOpen) return false;

    if (Date.now() - lastModalConfirmClickTime < 3000) return true;

    const allButtons = Array.from(
      document.querySelectorAll('button, a, input[type="button"], [role="button"]')
    ).filter(isVisible);

    // 1. Find the modal by finding "Return to Assessment" (which uniquely exists only on this popup)
    const returnBtn = allButtons.find((b) => {
      const txt = norm(b.innerText || b.value || '').toLowerCase();
      return txt.includes('return to assessment');
    });

    let completeBtn = null;
    if (returnBtn) {
      let cur = returnBtn.parentElement;
      while (cur && cur !== document.body && !completeBtn) {
        const cands = Array.from(cur.querySelectorAll('button, a, input[type="button"], [role="button"]')).filter(isVisible);
        completeBtn = cands.find((b) => {
          if (b === returnBtn) return false;
          return isCompleteAssessmentText(b.innerText || b.value || '');
        });
        cur = cur.parentElement;
      }
    }

    // 2. Fallback: Find any Complete Assessment button NOT located in the top header
    if (!completeBtn) {
      const candidates = allButtons.filter((b) => isCompleteAssessmentText(b.innerText || b.value || ''));
      completeBtn = candidates.find((b) => {
        const inHeader = b.closest('header, #t_Header, .t-Header, .t-Breadcrumb-item, .top-nav');
        const rect = b.getBoundingClientRect();
        return !inHeader && rect.top > 120;
      }) || candidates[candidates.length - 1];
    }

    if (completeBtn) {
      log('Popup Confirmation modal detected! Clicking popup Complete Assessment button:', completeBtn);
      reportState('Completing Assessment', 'Confirming Complete Assessment on modal popup');
      await sleep(700); // short pause on the modal
      lastModalConfirmClickTime = Date.now();
      triggerNavClick(completeBtn, 'Confirm Complete Assessment on Modal', true);

      // Navigate back to the course outline in the same tab as requested.
      setTimeout(async () => {
        const back = await findBackToCourseControl();
        if (back) {
          log('Confirm modal: clicking return-to-course control.');
          triggerNavClick(back, 'Post-confirm: return to course', true);
          return;
        }
        let stored = '';
        try {
          stored = sessionStorage.getItem('oracle_outline_url') || '';
        } catch (e) {}
        if (stored && stored.startsWith('http')) {
          log('Post-confirm: navigating to captured outline URL.');
          navigateTop(stored);
        }
      }, 1500);
      return true;
    }

    return false;
  }

  async function handleTopCompleteAssessment() {
    if (Date.now() - lastTopCompleteClickTime < 3000) return false;

    const buttons = Array.from(
      document.querySelectorAll('button, a, input[type="button"], input[type="submit"], [role="button"]')
    ).filter(isVisible);

    // Specifically target the top header/nav button first
    const topBtn = buttons.find((b) => {
      const isComplete = isCompleteAssessmentText(b.innerText || b.value || '');
      const inHeader = b.closest('header, #t_Header, .t-Header, .t-Breadcrumb-item, .top-nav');
      const rect = b.getBoundingClientRect();
      return isComplete && (inHeader || rect.top < 220);
    }) || buttons.find((b) => isCompleteAssessmentText(b.innerText || b.value || ''));

    if (topBtn) {
      log('Last question answered! Pausing briefly before clicking top Complete Assessment button...');
      reportState('Completing Assessment', 'Clicking top Complete Assessment button');
      await sleep(700); // short pause before clicking
      lastTopCompleteClickTime = Date.now();
      return triggerNavClick(topBtn, 'Click top Complete Assessment button', true);
    }

    return false;
  }

  // --- Navigation budget: no infinite redirect/reload loops --------------------
  // Any automatic page navigation/reload now consumes budget: max 6 per
  // 10 minutes. Exceeded -> the autopilot pauses instead of hijacking the tab
  // (you can always START SOLVING again from the popup, which resets it).
  let navs = []; // navigation budget timestamps
  function navBudgetOK() {
    const now = Date.now();
    navs = navs.filter((t) => now - t < 10 * 60 * 1000);
    if (navs.length >= 6) {
      warn('Navigation limit reached (6 in 10 min) — pausing. Press START SOLVING in the popup to retry.');
      reportState('Paused', 'Navigation limit — press START SOLVING to retry');
      return false;
    }
    navs.push(now);
    return true;
  }

  function navigateTop(url) {
    if (!url || !String(url).startsWith('http')) return false;
    const current = (typeof location !== 'undefined' ? location.href.split('#')[0] : '');
    if (current && url.split('#')[0] === current) return false; // never "reload" by navigating
    if (!navBudgetOK()) return false;
    try {
      if (window.self !== window.top && window.top) {
        window.top.location.href = url;
        return true;
      }
    } catch (e) {
      /* cross-origin — fall through to same-frame navigation */
    }
    location.href = url;
    return true;
  }

  // Remember the outline/course-list URL whenever a page looks like one —
  // independent of any specific Oracle page number, since accounts differ.
  function maybeCaptureOutlineUrl() {
    try {
      const href = location.href;
      if (!href || !href.includes('academy.oracle.com')) return;
      const text = bodyText();
      const rowStatuses = (text.match(/not\s*started|in\s*progress|\bcompleted\b/gi) || []).length;
      const looksLikeCourseList =
        rowStatuses >= 2 &&
        (/course|section|module|chapter|lesson|outline/i.test(document.title || '') ||
          /course\s+outline|sections?|modules?|chapter/i.test(text.slice(0, 3000)));
      if (!looksLikeCourseList) return;
      const stored = sessionStorage.getItem('oracle_outline_url');
      if (stored === href) return;
      sessionStorage.setItem('oracle_outline_url', href);
      log('Captured course outline URL:', href.slice(0, 90));
    } catch (e) {}
  }

  // After a quiz: prefer an on-page control ("Return to Course" etc.) over
  // any fabricated URL; stale hardcoded URLs caused the reload loops.
  async function findBackToCourseControl() {
    const cands = Array.from(document.querySelectorAll('a, button, [role="button"]')).filter(isVisible);
    const byText = cands.find((el) => {
      const t = norm(el.innerText || el.value || '').toLowerCase();
      return /back\s+to\s+course|return\s+to\s+course|back\s+to\s+class|course\s+outline|back\s+to\s+outline|back\s+to\s+section|return\s+to\s+section/.test(t);
    });
    if (byText) return byText;
    // Breadcrumb link naming the course (APEX style) — first link in header area.
    const crumbs = cands.filter((el) => el.closest('header, #t_Header, .t-Breadcrumb, .t-Breadcrumb-bar, nav'));
    for (const crumb of crumbs) {
      const t = norm(crumb.innerText || '').toLowerCase();
      if (/section|chapter|module|course|class|module/i.test(t) && t.length <= 80 && (crumb.getAttribute('href') || '').startsWith('http')) return crumb;
    }
    return null;
  }

  // Dynamically resolves where to go after a quiz: current-session outline URL
  // (captured live) -> redirect_url.txt via relay -> hardcoded last resort.
  async function getTargetOutlineUrl() {
    try {
      const stored = sessionStorage.getItem('oracle_outline_url');
      if (stored && stored.startsWith('http')) return stored.trim();
    } catch (e) {}
    try {
      const res = await api('GET', '/target-url');
      if (res && res.body && typeof res.body.url === 'string' && res.body.url.startsWith('http')) {
        return res.body.url.trim();
      }
    } catch (e) {}
    return CONFIG.TARGET_OUTLINE_URL;
  }

  // --- Score / Results Page Handlers ---
  async function handleScoreScreen() {
    const text = bodyText();
    const href = (typeof location !== 'undefined' && location.href) || '';

    // The course outline page itself can show "Score: 73%" section rows —
    // never treat an outline URL as a score screen, or we reload it forever.
    if (/f\?p=63000:14/.test(href)) return false;

    // Real result pages: need strong completion wording AND a percentage,
    // and must not be a section listing.
    const strong =
      /your\s+assessment\s+(is\s+)?(now\s+)?complete|assessment\s+(was\s+)?completed|congratulations/i.test(text);
    const numeric =
      /percentage\s+scored|score[^a-z]{0,12}\d+\s*%|mastery\s+score/i.test(text);
    const listPage = /not\s*started|in\s*progress/i.test(text) || /my\s*classes/i.test(text);
    if (!(strong && (numeric || /assessment/i.test(text))) || listPage) return false;

    // Bounce guard
    const lastNav = parseInt(sessionStorage.getItem('score_nav_at') || '0', 10);
    if (Date.now() - lastNav < 60000) return false;
    sessionStorage.setItem('score_nav_at', String(Date.now()));

    // FIRST: record incorrect rows so the retake re-solves them with the API;
    // clear the ledger the moment we finally hit 100%.
    const mPctLedger = text.match(/(\d{1,3})\s*%/i);
    if (mPctLedger && parseInt(mPctLedger[1], 10) >= 100) {
      clearWrongList();
    } else {
      captureWrongRows();
    }

    // Auto-retake: if the score is below 100%, click the retake button (up to
    // 5 attempts). Stale AI answers are ignored on retakes so the API can
    // re-solve the ones it got wrong.
    const mPct = text.match(/(\d{1,3})\s*%/i);
    if (mPct) {
      const score = parseInt(mPct[1], 10);
      const attempts = parseInt(sessionStorage.getItem('auto_attempts') || '0', 10);
      if (score >= 100) {
        sessionStorage.setItem('auto_attempts', '0');
        log('Score is 100% — continuing to the next section.');
      } else if (attempts < 5) {
        const retakeBtn = Array.from(
          document.querySelectorAll('button, a, input[type="button"], input[type="submit"], [role="button"]')
        ).filter(isVisible).find((b) => {
          const t = norm(b.innerText || b.value || '').toLowerCase();
          return /retake|try\s+again|re[\s-]??attempt|restart|new\s+attempt|take\s+(an|the)\s+assessment|attempt\s+again|assessment\s+again|take\s+assessment|start\s+over/i.test(t);
        });
        if (retakeBtn) {
          sessionStorage.setItem('auto_attempts', String(attempts + 1));
          log(`Score ${score}% < 100% — auto-retaking (attempt ${attempts + 2}/6). Wrong AI answers will be re-solved against the API.`);
          return triggerNavClick(retakeBtn, `Auto-retake (score ${score}%)`, true);
        }
        sendDiag('score-low-no-retake-button', '', []);
      } else {
        warn(`Still below 100% after ${attempts + 1} attempts — moving on to the next section.`);
        sessionStorage.setItem('auto_attempts', '0');
        sendDiag('score-still-low', '', []);
      }
    }

    reportState('Navigating', 'Score screen: returning to the course');

    // 1) Trust the page's own return control when one exists.
    const back = await findBackToCourseControl();
    if (back) {
      log('Score screen: clicking return-to-course control.');
      const lastNavAt = parseInt(sessionStorage.getItem('score_nav_at') || '0', 10);
      sessionStorage.setItem('score_nav_at', String(Date.now()));
      return triggerNavClick(back, 'Score screen: return to course', true);
    }

    // 2) The outline URL captured from THIS browsing session (trustworthy —
    // it is the exact page we were on minutes ago).
    let stored = '';
    try {
      stored = sessionStorage.getItem('oracle_outline_url') || '';
    } catch (e) {}
    if (stored && stored.startsWith('http')) {
      const lastNavStored = parseInt(sessionStorage.getItem('score_nav_at') || '0', 10);
      if (Date.now() - lastNavStored > 30000) {
        sessionStorage.setItem('score_nav_at', String(Date.now()));
        return navigateTop(stored);
      }
    }

    // 3) Last resort: go back one step in the SPA flow (once).
    const lastNavStored2 = parseInt(sessionStorage.getItem('score_nav_at') || '0', 10);
    if (Date.now() - lastNavStored2 > 30000) {
      sessionStorage.setItem('score_nav_at', String(Date.now()));
      log('No return control or captured outline — going back one page.');
      history.back();
    }
    return true;
  }

  // --- Lesson Reading / Slide Advancement ---
  let lastLessonNextClickTime = 0;
  function handleLessonNext() {
    // After "Save and Continue" the same button stays visible until the next
    // slide loads; re-clicking too fast can skip content or double-advance.
    // 3s gives the page time to transition.
    if (Date.now() - lastLessonNextClickTime < 3000) return false;

    const buttons = Array.from(
      document.querySelectorAll('button, a, input[type="button"], input[type="submit"], [role="button"]')
    ).filter(isVisible);

    // Lesson context prevents clicking generic "Next"/"Continue" buttons on
    // unrelated pages (dashboards, navs) — only advance when the page itself
    // looks like a lesson/slide flow.
    const pageText = bodyText();
    const lessonCtx = /save\s*(and|&)\s*(continue|progress|next)|next\s*(slide|lesson)|mark\s*as\s*complete|slide\s+\d+\s+of\s+\d+/i.test(pageText);

    for (const b of buttons) {
      const txt = norm(b.innerText || b.value || '').toLowerCase();
      const explicit =
        txt.includes('save and continue') ||
        txt.includes('save & continue') ||
        txt.includes('save progress') ||
        txt.includes('save & progress') ||
        txt.includes('save and next') ||
        txt.includes('save & next') ||
        txt === 'next lesson' ||
        txt === 'next slide' ||
        txt === 'mark as complete';
      const generic = txt === 'continue' || txt === 'next';
      if (explicit || (generic && lessonCtx)) {
        lastLessonNextClickTime = Date.now();
        log(`Found lesson advancement button: "${txt}". Clicking once and waiting...`);
        return triggerNavClick(b, `Advance Lesson: ${txt}`, true);
      }
    }
    return false;
  }

  // --- Start Assessment / Quiz ---
  async function handleStartAssessment() {
    const text = bodyText();

    // 1. Check if the Start Assessment Popup Modal is visible
    const isModalOpen =
      /Click\s+Start\s+to\s+begin\s+assessment/i.test(text) ||
      /first\s+of\s+unlimited\s+attempts/i.test(text) ||
      /begin\s+assessment/i.test(text);

    if (isModalOpen) {
      const buttons = Array.from(
        document.querySelectorAll('button, a, input[type="button"], [role="button"]')
      ).filter(isVisible);

      const startBtn = buttons.find((b) => {
        const txt = norm(b.innerText || b.value || '').toLowerCase();
        return txt === 'start' || txt === 'start assessment' || txt === 'begin assessment';
      });

      if (startBtn) {
        log('Found "Start" button on popup modal! Pausing briefly before clicking...');
        reportState('Starting Assessment', 'Clicking Start button on popup');
        await sleep(700); // short pause on the popup as requested
        const clicked = triggerNavClick(startBtn, 'Click Start on Popup Modal', true);
        if (clicked) {
          log('Start button clicked! Waiting 1000ms for quiz to settle...');
          await sleep(1000); // wait 1 second after pressing start
          return true;
        }
        return false;
      }
    }

    // 2. Check if the "Take an Assessment" button is present on the page
    const buttons = Array.from(
      document.querySelectorAll('button, a, input[type="button"], [role="button"]')
    ).filter(isVisible);

    const takeAssessmentBtn = buttons.find((b) => {
      const txt = norm(b.innerText || b.value || '').toLowerCase();
      return txt === 'take an assessment' || txt.includes('take an assessment');
    });

    if (takeAssessmentBtn) {
      log('Found "Take an Assessment" button. Clicking...');
      return triggerNavClick(takeAssessmentBtn, 'Click Take an Assessment');
    }

    return false;
  }

  // --- Course Outline Navigation ---
  // Automatically opens the NEXT unfinished section on the outline page.
  // Detection is content-based (rows with status/percentage), not URL-based,
  // so it works no matter which page id the account uses.
  function handleCourseOutline() {
    if (Date.now() - lastOutlineNavTime < 4000) return false;

    const text = bodyText();
    // Needs section-ish listings with at least two status rows to act.
    const rowMatches = text.match(/not\s*started|in\s*progress|\bcompleted\b|\bpassed\b|resume|continue/gi) || [];
    const pctMatches = text.match(/\b\d{1,3}\s*%/g) || [];
    const looksLikeOutline =
      (rowMatches.length >= 2 && /course|section|module|chapter|outline/i.test(text.slice(0, 3000))) ||
      pctMatches.length >= 2;
    if (!looksLikeOutline) return false;
    if (Date.now() - lastOutlineNavTime < 4000) return false;

    const clickables = Array.from(
      document.querySelectorAll('a, button, [role="button"], tr[onclick]')
    ).filter(isVisible);

    let best = null;
    for (const el of clickables) {
      let container = el.closest('tr, li, article') || el.closest('.row, div.t-Report-row') || el;
      let statusText = norm(container.innerText || '');
      if (statusText.length > 400) {
        container = el.closest('tr, li') || el;
        statusText = norm(container.innerText || '');
      }
      if (statusText.length > 400) continue;

      const s = statusText.toLowerCase();
      if (/\bcompleted\b|\bpassed\b|\b100\s*%\b|score\s*report/i.test(s)) continue; // finished — skip
      const isSectionRow =
        /not\s*started|in\s*progress|resume|continue/.test(s) ||
        (/\b(\d{1,2})\s*%/.test(s) && parseInt((s.match(/\b(\d{1,2})\s*%/) || [])[1], 10) < 100);
      if (!isSectionRow) continue;
      best = { el, statusText };
      break; // first incomplete section in course order wins
    }

    if (!best) return false;
    lastOutlineNavTime = Date.now();
    try {
      sessionStorage.setItem('auto_attempts', '0');
      sessionStorage.removeItem('wrongq'); // fresh section, fresh ledger
    } catch (e) {}
    log('Course outline: opening next incomplete section ->', best.statusText.slice(0, 80));
    return triggerNavClick(best.el, `Open next section: ${best.statusText.slice(0, 40)}`, true);
  }

  // --- Front Page Handlers (p=63000:1) ---
  function handleFrontPage() {
    const text = bodyText();
    if (!/my\s*student\s*benefits/i.test(text)) {
      return false;
    }
    const all = Array.from(document.querySelectorAll('a, button, h2, h3, h4, span, div')).filter(isVisible);
    for (const el of all) {
      if (norm(el.innerText) === 'My Classes') {
        const clickable = el.closest('a') || (el.tagName === 'A' ? el : el.parentElement.querySelector('a') || el);
        return triggerNavClick(clickable, 'Click My Classes from Front Page');
      }
    }
    return false;
  }

  // --- Classes Dashboard ("Take Class") ---
  function findTakeClassButtonFor(targetCls) {
    const clean = (s) => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const targetClean = clean(targetCls);

    const allTakeButtons = Array.from(document.querySelectorAll('button, a')).filter((b) => {
      const txt = norm(b.innerText || b.value || '').toLowerCase();
      return isVisible(b) && (txt === 'take class' || txt.includes('take class'));
    });

    for (const btn of allTakeButtons) {
      let cur = btn.parentElement;
      while (cur && cur !== document.body) {
        const textClean = clean(cur.innerText || '');
        if (textClean.includes(targetClean)) {
          // Verify this container does NOT contain sibling target classes (prevent parent grid matching)
          const otherClasses = CONFIG.TARGET_CLASSES.filter((c) => clean(c) !== targetClean);
          const hasOthers = otherClasses.some((other) => textClean.includes(clean(other)));
          if (!hasOthers) {
            return btn;
          }
        }
        cur = cur.parentElement;
      }
    }
    return null;
  }

  function handleClassesDashboard() {
    const text = bodyText();
    if (!/classes/i.test(text) && !/my\s*classes/i.test(text)) return false;

    let completedCourses = ['Database Foundations'];
    try {
      const stored = JSON.parse(localStorage.getItem('oracle_completed_classes') || '[]');
      completedCourses = Array.from(new Set([...completedCourses, ...stored]));
    } catch (e) {}

    const clean = (s) => (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');

    for (const targetCls of CONFIG.TARGET_CLASSES) {
      if (completedCourses.some((c) => clean(c) === clean(targetCls))) {
        continue;
      }

      const takeBtn = findTakeClassButtonFor(targetCls);
      if (takeBtn) {
        log(`Found isolated Take Class button for "${targetCls}":`, takeBtn);
        return triggerNavClick(takeBtn, `Enter Next Class: ${targetCls}`);
      }
    }

    return false;
  }

  // --- Section idle recovery: go back to the outline on its own ----------------
  // If the autopilot sits on a page where none of the handlers can act for
  // 90s (no quiz, no lesson buttons, no outline rows), it returns to the
  // course list autonomously so the run keeps flowing between sections.
  let idleAnchorTime = 0;
  function sectionIdleTick() {
    const now = Date.now();
    if (!idleAnchorTime) {
      idleAnchorTime = now;
      return false;
    }
    const lastActivity = Math.max(lastNavActionTime, idleAnchorTime);
    if (now - lastActivity < 90000) return false;
    idleAnchorTime = now; // re-trigger no sooner than 90s later
    log('No progress on this page for 90s — going back to the course outline.');
    sendDiag('section-idle-return', '');
    const back = findBackToCourseControl();
    if (back) return triggerNavClick(back, 'Idle: back to course list', true);
    let stored = '';
    try {
      stored = sessionStorage.getItem('oracle_outline_url') || '';
    } catch (e) {}
    if (stored && stored.startsWith('http')) return navigateTop(stored);
    return false;
  }

  let lastSeenUrl = typeof location !== 'undefined' ? location.href : '';

  // Current "Question X of Y" identifier, e.g. "4/15" ('' when not on a quiz).
  function questionNumberOnPage() {
    const m = bodyText().match(/question\s+(\d+)\s+of\s+(\d+)/i);
    return m ? `${m[1]}/${m[2]}` : '';
  }

  // Watchdog: if the SAME question number stays on screen for 20s/45s/75s we
  // escalate — re-click submit -> alternate submit strategies -> one reload.
  // This is what un-sticks the "keeps solving the same question" failure mode.
  function quizWatchdogTick() {
    const qNum = questionNumberOnPage();
    if (!qNum) {
      quizWatch.qNum = '';
      return;
    }
    if (qNum !== quizWatch.qNum) {
      quizWatch.qNum = qNum;
      quizWatch.firstSeen = Date.now();
      quizWatch.submitRetried = false;
      quizWatch.altTried = false;
      quizWatch.reloadQueued = false;
      return;
    }
    const stuckMs = Date.now() - quizWatch.firstSeen;
    // The last question is the riskiest: escalate much faster so the run
    // never stalls at the finish line.
    const isLast = checkIsLastQuestion();
    const T1 = isLast ? 12000 : 20000;
    const T2 = isLast ? 25000 : 45000;
    const T3 = isLast ? 40000 : 75000;
    if (stuckMs < T1 || Date.now() - lastNavActionTime < 3000) return;

    if (stuckMs > T3 && !quizWatch.reloadQueued) {
      quizWatch.reloadQueued = true;
      const lastReload = parseInt(sessionStorage.getItem('quiz_reload_at') || '0', 10);
      if (Date.now() - lastReload > 300000) {
        sessionStorage.setItem('quiz_reload_at', String(Date.now()));
        warn(`Question stuck >${T3 / 1000}s — reloading the page once to recover.`);
        location.reload();
        return;
      }
    }
    if (stuckMs > T2 && !quizWatch.altTried) {
      quizWatch.altTried = true;
      warn(`Question stuck >${T2 / 1000}s — trying alternate submit strategies.`);
      tryAlternateSubmit();
      return;
    }
    if (!quizWatch.submitRetried) {
      quizWatch.submitRetried = true;
      warn(`Question stuck >${T1 / 1000}s — re-clicking Submit Answer.`);
      clickSubmitAnswer();
    }
  }

  // --- Main Autopilot Loop ---
  async function autopilotCycle() {
    const currentHref = typeof location !== 'undefined' ? location.href : '';
    if (currentHref !== lastSeenUrl) {
      lastSeenUrl = currentHref;
      lastSubmittedSnippet = '';
      unansweredAttempts = 0;
      idleAnchorTime = Date.now();
    }

    if (isSolvingQuiz) {
      if (solvingQuizStartTime && Date.now() - solvingQuizStartTime > 20000) {
        warn('runQuizFlow hung for >20s, resetting isSolvingQuiz flag');
        isSolvingQuiz = false;
      } else {
        return;
      }
    }

    // 0. Kill switch (popup toggle)
    if (!autopilotEnabled) return;

    // 0.5 Access control: idle while locked out (popup login required).
    await probeAuth();
    if (authState.required && !authState.ok) {
      reportState('Locked', 'Login required — open the extension popup and sign in');
      return;
    }

    // Remember the outline URL whenever we see it (enables clean post-quiz redirects).
    maybeCaptureOutlineUrl();

    // 1. Confirm Complete Assessment Modal (if open)
    if (await handleConfirmCompleteModal()) return;

    // 2. Active Quiz Question (Highest Priority)
    const text = bodyText();
    const hasInputs = document.querySelector('input[type="radio"], input[type="checkbox"], button.choice-SelectArea') !== null;
    const hasSubmitHint = /submit\s+answer/i.test(text);
    const hasQuestion =
      /question\s+\d+\s+of\s+\d+/i.test(text) ||
      (hasSubmitHint && (hasInputs || /choices/i.test(text)));

    if (hasQuestion && (hasInputs || hasSubmitHint)) {
      if (checkIsLastQuestion() && isLastQuestionAnsweredAndSelected()) {
        if (await handleTopCompleteAssessment()) return;
      }

      quizWatchdogTick();
      await runQuizFlow();
      return;
    }

    // 3. Score / Results Page -> Redirect to Course Outline in the same tab
    if (await handleScoreScreen()) return;

    // 4. Start Assessment ("Take an Assessment" -> short pause -> popup "Start")
    if (await handleStartAssessment()) return;

    // 5. Lesson slide "Save and Continue" / "Save Progress"
    if (handleLessonNext()) return;

    // 6. Course outline page -> open the next unfinished section automatically
    if (handleCourseOutline()) return;

    // 7. Idle too long with nothing actionable? Go back to the outline.
    if (sectionIdleTick()) return;

    // Idle heartbeat reporting
    reportState('Monitoring Page', norm(document.title));
  }

  let autopilotInterval = null;
  function startAutopilot() {
    if (autopilotInterval) return;
    autopilotInterval = setInterval(autopilotCycle, CONFIG.LOOP_INTERVAL_MS);
    log('Autonomous Oracle Auto-Pilot initialized & running.');
  }

  function stopAutopilot() {
    if (autopilotInterval) {
      clearInterval(autopilotInterval);
      autopilotInterval = null;
      log('Autonomous Oracle Auto-Pilot stopped/paused.');
    }
  }

  // Resume automatically whenever URL changes (e.g. back to home/outline)
  if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
    window.addEventListener('popstate', () => {
      isQuizCompletedAwaitingUser = false;
      startAutopilot();
    });
    window.addEventListener('hashchange', () => {
      isQuizCompletedAwaitingUser = false;
      startAutopilot();
    });
  }

  startAutopilot();
})();